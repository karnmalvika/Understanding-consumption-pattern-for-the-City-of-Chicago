DROP SCHEMA
IF EXISTS albany_park;

CREATE SCHEMA albany_park COLLATE = utf8_general_ci;
use albany_park;

CREATE TABLE community (
	community_id INT NOT NULL,
    community_area_name VARCHAR(40), 
    PRIMARY KEY (community_id) 
);

CREATE TABLE census_block (
	census_block_id INT NOT NULL,
    census_block BIGINT,
    community_id INT NOT NULL,
    PRIMARY KEY (census_block_id),
    FOREIGN KEY (community_id) REFERENCES community (community_id)
);

CREATE TABLE b_type (
	b_type_id INT NOT NULL,
    b_type VARCHAR(20),
    PRIMARY KEY (b_type_id)
);

CREATE TABLE subtype (
	subtype_id INT NOT NULL,
    subtype VARCHAR(20),
    PRIMARY KEY (subtype_id)
);

CREATE TABLE building (
    building_id INT NOT NULL,
    b_type_id INT NOT NULL,
    subtype_id INT NOT NULL,
    census_block_id INT NOT NULL,
    population INT NULL,
    total_units INT NULL,
    avg_stories DECIMAL(6 , 2 ) NULL,
    avg_building_age DECIMAL(6 , 2 ) NULL,
    avg_housesize DECIMAL(6 , 2 ) NULL,
    occupied_units INT NULL,
    renter_occupied_units INT NULL,
    PRIMARY KEY (building_id),
    FOREIGN KEY (b_type_id) REFERENCES b_type (b_type_id),
    FOREIGN KEY (subtype_id) REFERENCES subtype (subtype_id),
    FOREIGN KEY (census_block_id) REFERENCES census_block (census_block_id)
);

CREATE TABLE kwh ( 
	building_id INT NOT NULL,
	kwh_jan INT NULL,
    kwh_feb INT NULL,
    kwh_mar INT NULL,
    kwh_apr INT NULL,
    kwh_may INT NULL,
    kwh_jun INT NULL,
    kwh_jul INT NULL,
    kwh_aug INT NULL,
    kwh_sep INT NULL,
    kwh_oct INT NULL,
    kwh_nov INT NULL,
    kwh_dec INT NULL,
    electricity_accounts VARCHAR(20),
    zero_kwh_accounts INT NULL,
	kwh_total_sqft INT NULL,
    FOREIGN KEY (building_id) REFERENCES building (building_id)
);

CREATE TABLE therm ( 
	building_id INT NOT NULL,
	therm_jan INT NULL,
    therm_feb INT NULL,
    therm_mar INT NULL,
    therm_apr INT NULL,
    therm_may INT NULL,
    therm_jun INT NULL,
    therm_jul INT NULL,
    therm_aug INT NULL,
    therm_sep INT NULL,
    therm_oct INT NULL,
    therm_nov INT NULL,
    therm_dec INT NULL,
    gas_accounts VARCHAR(20),
    therms_total_sqft INT NULL,
    FOREIGN KEY (building_id) REFERENCES building (building_id)
);

CREATE TABLE kwh_stats ( 

	building_id INT NOT NULL,
    kwh_mean TEXT NULL,
	kwh_std_dev TEXT NULL,
	kwh_min TEXT NULL,
	kwh_first_quartile TEXT NULL,
	kwh_second_quartile	TEXT NULL,
    kwh_thid_quartile TEXT NULL,
    kwh_max TEXT NULL,
	kwh_sqft_min TEXT NULL,
	kwh_sqft_max TEXT NULL,
	total_kwh TEXT NULL,
    FOREIGN KEY (building_id) REFERENCES kwh (building_id)
);

CREATE TABLE therm_stats ( 
	building_id INT NOT NULL,
    total_therm TEXT NULL,
	therm_mean TEXT NULL,
	therm_std_dev TEXT NULL,
	therm_min TEXT NULL,
	therm_first_quartile TEXT NULL,
	therm_second_quartile TEXT NULL,
    therm_third_quartile TEXT NULL,
	therm_max TEXT NULL,
	therm_sqft_mean	TEXT NULL,
    therm_sqft_min TEXT NULL,    
	
    FOREIGN KEY (building_id) REFERENCES therm (building_id)
);



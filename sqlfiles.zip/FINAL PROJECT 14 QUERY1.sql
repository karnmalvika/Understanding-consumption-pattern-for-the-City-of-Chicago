############################################################################################ ENERGY CONSUMPTION PATTERN USING SQL QUERY ANALYSIS ###################
##################################################################################

# QUERY 1 Create a query to produce a list from one table
SELECT * FROM albany_park.building;

#QUERY 2 Create a query to provide data results that includes one or more conditions.
SELECT * FROM building
WHERE avg_building_age >50 AND
occupied_units != 0;

#Query 3 Create a query that links 2 tables and provides data from both.
SELECT therm_stats.* ,therm.*
FROM therm_stats JOIN therm 
USING(building_id) ;

#Query 4 Create a query that links 2 OR more tables and provides data from them with condition
#-Building type from b_type table
#Total units from building table and attaches them total thermal energy usage and avg thermal energy usage  which is from thermal_stats table
SELECT bt.b_type,
SUM(b.total_units) AS 'Total units',
SUM(ts.total_therm) AS 'Total Thermal Energy usage',
AVG(ts.total_therm) AS 'Avg thermal energy usage'
FROM therm_stats ts JOIN therm t
USING(building_id) JOIN building b
USING(building_id) JOIN b_type bt
USING(b_type_id) JOIN subtype s USING(subtype_id)
GROUP BY bt.b_type
ORDER BY AVG(ts.total_therm) DESC;

#Query 5 Create a query that inserts data into a table.
INSERT INTO `building`(`building_id`, `b_type_id`, `subtype_id`, `census_block_id`, `population`, `total_units`, `avg_stories`, `avg_building_age`, `avg_housesize`, `occupied_units`, `renter_occupied_units`)
            VALUES(10154,1,1,6,250,25,1.33,25,3.22,14,3);
SELECT * FROM building WHERE building_id = 10154;   

#Query 6 Create a query that removes some data from a table but not all the data.The same row inserted by the previous query is deleted.
DELETE FROM building 
WHERE building_id =10154;

SELECT * FROM building
WHERE building_id =10154;

#Query 7 Create a query to display Thermal Energy usage by Asset Class.
#-Join Building type from b_type table
#-Total units from building table and attaches them total thermal energy usage and avg thermal energy usage  which is from thermal_stats table
SELECT bt.b_type,
SUM(b.total_units) AS 'Total units',
SUM(ts.total_therm) AS 'Total Thermal Energy usage',
AVG(ts.total_therm) AS 'Avg thermal energy usage'
FROM therm_stats ts JOIN therm t
USING(building_id)
JOIN building b
USING(building_id)
JOIN b_type bt
USING(b_type_id)
JOIN subtype s
USING(subtype_id)
GROUP BY bt.b_type
ORDER BY AVG(ts.total_therm) DESC;

#Total Thermal energy usage is highest for residential while lowest for industrial (which is just about 0.08% of total Thermal energy )
#There is not much difference in avg thermal energy usage


#Query 8 Create a query to display kwh Energy usage by Asset Class
#-Join Building type from b_type table,
#-Total units from building table and attach them total kwh energy usage and avg kwh energy usage  which is from kwh_stats table
SELECT bt.b_type,
SUM(b.total_units) AS 'Total units',
SUM(ks.total_kwh) AS 'Total KWH Energy usage',
AVG(ks.total_kwh) AS 'Avg KWH Energy usage'
FROM kwh_stats ks 
JOIN kwh k 
USING(building_id)
JOIN building b 
USING (building_id)
JOIN b_type bt 
USING(b_type_id)
JOIN subtype s 
USING (subtype_id)
GROUP BY bt.b_type
ORDER BY AVG(ks.total_kwh) DESC;

#Total kwh energy usage is highest for residential(around 60% of total kwh energy usage) while lowest for industrial Avg thermal energy usage is highest for commercial


#Query 9 Create a query to display Thermal Energy efficiency based on building Sub type
#-Join Tables :therm_stats, therm, building, b_type, subtype
#-Group by using subtype
SELECT bt.b_type,
s.subtype,
AVG(ts.total_therm) AS 'avg Thermal Energy usage'
FROM therm_stats ts 
JOIN therm t
USING (building_id) 
JOIN building b
USING (building_id) 
JOIN b_type bt
USING (b_type_id) 
JOIN subtype s 
USING (subtype_id)
GROUP BY s.subtype
ORDER BY AVG(ts.total_therm) DESC;


#Query 10 Create a query to display kwh Energy efficiency based on building Sub type .
#-Join Tables :kwh_stats, kwh, building, b_type, subtype
#Group by using subtype
SELECT s.subtype,
bt.b_type,
AVG(ks.total_kwh) AS 'avg kwh Energy usage'
FROM kwh_stats ks 
JOIN kwh k
USING(building_id) 
JOIN building b
USING(building_id) 
JOIN b_type bt
USING(b_type_id) 
JOIN subtype s 
USING(subtype_id)
GROUP BY s.subtype
ORDER BY AVG(ks.total_kwh) DESC;

                                                                     
#Query 11 Create a query to display Thermal Energy Factoring building age ,house size , avg stories
#-Join Tables :therm_stats , therm, building, b_type , subtype
#-Group by using subtype
SELECT b.building_id,
b.census_block_id,
bt.b_type,
b.avg_building_age,
b.avg_stories,
b.avg_housesize,
b.total_units,
ts.total_therm
FROM therm_stats ts 
JOIN therm t
USING(building_id) 
JOIN building b
USING (building_id) 
JOIN b_type bt
USING(b_type_id) 
JOIN subtype s 
USING(subtype_id)
ORDER BY b.avg_building_age DESC;


#Query 12 Create a query to display kwh Energy Factoring building age , house size , avg  stories
#-Join Tables :kwh_stats , kwh, building, b_type , subtype
#-Group by using subtype
SELECT b.building_id,
b.census_block_id,
bt.b_type,
b.avg_building_age,
b.avg_stories,
b.avg_housesize,
b.total_units,
ks.total_kwh
FROM kwh_stats ks 
JOIN kwh k
USING(building_id) 
JOIN building b
USING(building_id) 
JOIN b_type bt
USING(b_type_id) 
JOIN subtype s
USING(subtype_id)
ORDER BY b.avg_building_age DESC;


#Query 13 Create a query to display Seasonal variance  of Thermal energy using monthly data
#-Average energy usage value of every month is gathered  together to observe seasonal effects using select query from ‘therm’ table.
SELECT AVG(therm_jan) AS 'JAN', 
AVG(therm_feb) AS 'FEB',
AVG(therm_mar) AS 'MAR',
AVG(therm_apr) AS 'APR',
AVG(therm_may) AS 'MAY',
AVG(therm_jun) AS 'JUN',
AVG(therm_jul) AS 'JUL',
AVG(therm_aug) AS 'AUG',
AVG(therm_sep) AS 'SEPT',
AVG(therm_oct) AS 'OCT',
AVG(therm_nov) AS 'NOV',
AVG(therm_dec) AS 'DEC' 
FROM therm;
#HERE WE CAN OBSERVE THAT ENERGY USAGE STARTED TO INCREASE AS WINTER STARTED. i.e. FROM NOV TO APR. IT REACHES TO PEAK IN JAN. AGAIN AS SUMMER STARTS IT STARTED TO DECREASE i.e. FROM MAY TO OCT. ITS LEAST IN AUG


#Query 14 Create a query to display Seasonal variance of kwh energy using monthly data 
#-Average energy usage value of every month is gathered  together to observe seasonal effects using select query from ‘kwh’ table. 
SELECT AVG(kwh_jan) AS 'JAN', 
AVG(kwh_feb) AS 'FEB',
AVG(kwh_mar) AS 'MAR',
AVG(kwh_apr) AS 'APR',
AVG(kwh_may) AS 'MAY',
AVG(kwh_jun) AS 'JUN',
AVG(kwh_jul) AS 'JUL',
AVG(kwh_aug) AS 'AUG',
AVG(kwh_sep) AS 'SEPT',
AVG(kwh_oct) AS 'OCT',
AVG(kwh_nov) AS 'NOV',
AVG(kwh_dec) AS 'DEC'
FROM kwh;
#HERE WE CAN OBSERVE THAT ENERGY USAGE IS PEAK FOR JUN AND JULY FOLLOWED BY NOV AND DEC. FOR 1ST 4 MONTHS i.e. JAN TO APR ITS SOMEWHAT CONSTANT i.e. ABOUT 5200
#WE CAN CONCLUDE THAT TOTAL KWH IS HIGHER THAN THAT OF TOTAL THERMAL

